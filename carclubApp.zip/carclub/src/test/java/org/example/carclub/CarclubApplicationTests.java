package org.example.carclub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarclubApplicationTests {

    @Test
    void contextLoads() {
    }

}
