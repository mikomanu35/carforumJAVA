package org.example.carclub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CarclubApplication {
    public static void main(String[] args) {
SpringApplication.run(CarclubApplication.class, args);
    }

}
