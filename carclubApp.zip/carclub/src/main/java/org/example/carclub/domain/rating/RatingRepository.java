package org.example.carclub.domain.rating;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface RatingRepository extends CrudRepository<Rating,Long> {

    Optional<Rating> findByUser_EmailAndCar_Id(String email, Long carId);

    @Transactional
    @Modifying
    @Query("DELETE FROM Rating c WHERE c.car.id = :id")
    void deleteCarById(@Param("id") Long id);
}
