insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Lexus', 'IS-F', 'Luksusowy sedan sportowy.', 'Lexus IS-F z 2011 roku to połączenie luksusu i dynamicznej jazdy. Z potężnym silnikiem i eleganckim designem zapewnia ekscytujące doznania za kierownicą.', 2011, 'fYKQMRnOlR0', 5, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('BMW', '530', 'Elegancki sedan klasy premium.', 'BMW 530 z 2007 roku łączy w sobie komfort klasy premium z dynamicznym osiągiem. Jego zaawansowany design i innowacyjne funkcje sprawiają, że to ponadczasowy wybór dla wymagających kierowców.', 2007, 'feWMqBI8gms', 10, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Cadillac', 'Escalade EXT', 'Luksusowy SUV z uniwersalnym bagażnikiem.', 'Cadillac Escalade EXT z 2008 roku to luksusowy SUV z wszechstronnym miejscem na bagaż. Wprowadza elegancję i innowację, dostarczając premium wrażeń z jazdy i podróży.', 2008, 'lig9_A0Cyt0', 5, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('BMW', 'X5 M', 'Wysokowydajny SUV z długą tradycją.', 'BMW X5 M z 2011 roku to wysokowydajny SUV, łączący luksusowe cechy z potężnym osiągiem. Zaprojektowany dla tych, którzy poszukują stylu i ekscytującej dynamiki jazdy.', 2011, 'feWMqBI8gms', 6, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Lexus', 'LS Hybrid', 'Klasyczny sedan z napędem hybrydowym.', 'Lexus LS Hybrid z 2011 roku to połączenie luksusu i ekologicznej technologii. Jego wyrafinowany design i efektywność hybrydowa sprawiają, że jest to doskonały wybór dla tych, którzy cenią zarówno elegancję, jak i zrównoważone rozwiązania.', 2011, 'lig9_A0Cyt0', 10, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Ford', 'Taurus', 'Klasyczny sedan.', 'Ford Taurus z 1990 roku to klasyczny sedan z komfortową jazdą. Jego ponadczasowy design i niezawodne osiągi sprawiają, że jest to zaufany wybór dla rodzin i codziennych dojazdów.', 1990, 'gThLfTHR9q0', 9, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Dodge', 'Magnum', 'Muscle car z charakterystycznym designem.', 'Dodge Magnum z 2008 roku to potężny muscle car o wyrazistym designie. Jego mocne osiągi i przestronne wnętrze sprawiają, że jest odważnym wyborem dla miłośników emocji z jazdy na otwartych drogach.', 2008, 'feWMqBI8gms', 3, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Mazda', 'CX-7', 'Elastyczny SUV.', 'Mazda CX-7 z 2007 roku to elastyczny SUV o atrakcyjnym designie. Jego wszechstronne możliwości sprawiają, że jest idealny do codziennych podróży i przygód na drogach.', 2007, 'wPvBvRS6OQE', 6, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Pontiac', 'Grand Prix', 'Elegancki sedan z mocnym silnikiem.', 'Pontiac Grand Prix z 2008 roku to elegancki sedan z silnikiem o potężnych osiągach. Jego stylowa sylwetka i dynamiczne możliwości sprawiają, że jest to pewny wybór dla miłośników sportowego stylu jazdy.', 2008, 'fYKQMRnOlR0', 8, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Land Rover', 'Range Rover Sport', 'Luksusowy SUV terenowy.', 'Land Rover Range Rover Sport z 2011 roku to luksusowy SUV terenowy, łączący elegancję z doskonałymi możliwościami off-road. Zapewnia niesamowity komfort podróży i niezawodność w każdych warunkach.', 2011, 'lig9_A0Cyt0', 1, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Nissan', 'Maxima', 'Elegancki sedan z wydajnym silnikiem.', 'Nissan Maxima z 1990 roku to elegancki sedan z wydajnym silnikiem. Jego precyzyjne osiągi i stylowy design sprawiają, że jest to popularny wybór dla osób ceniących komfort i dynamikę jazdy.', 1990, 'wPvBvRS6OQE', 9, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Mitsubishi', 'Eclipse', 'Szybki coupe z pasją do jazdy.', 'Mitsubishi Eclipse z 1995 roku to szybkie coupe dla pasjonatów jazdy. Jego dynamiczny charakter i wyjątkowy design sprawiają, że jest to doskonały wybór dla miłośników emocji za kierownicą.', 1995, 'gThLfTHR9q0', 8, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Mitsubishi', 'Excel', 'Kompaktowy samochód z charakterem.', 'Mitsubishi Excel z 1987 roku to kompaktowy samochód z charakterem. Jego praktyczne rozmiary i stylowy wygląd sprawiają, że jest idealny do miejskiej jazdy z pasją.', 1987, 'gThLfTHR9q0', 2, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Plymouth', 'Laser', 'Sportowe coupe z dynamiką jazdy.', 'Plymouth Laser z 1990 roku to sportowe coupe z pasją do dynamicznej jazdy. Jego agresywny design i osiągi sprawiają, że jest to wybór dla miłośników sportowego stylu za kierownicą.', 1990, 'gThLfTHR9q0', 4, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Mitsubishi', 'Sigma', 'Elegancki sedan z wyrafinowanym wnętrzem.', 'Mitsubishi Sigma z 1990 roku to elegancki sedan z wyrafinowanym wnętrzem. Jego komfortowe cechy i stylowy design sprawiają, że jest to doskonały wybór dla osób ceniących luksus i wygodę.', 1990, 'fYKQMRnOlR0', 4, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Mazda', 'Miata MX-5', 'Klasyczny roadster z pasją do jazdy.', 'Mazda Miata MX-5 z 2007 roku to klasyczny roadster dla miłośników jazdy z pasją. Jego lekka konstrukcja i zwrotność sprawiają, że dostarcza niezapomnianych wrażeń za kierownicą.', 2007, 'feWMqBI8gms', 1, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Mercedes-Benz', '400SE', 'Luksusowy sedan z elegancją.', 'Mercedes-Benz 400SE z 1992 roku to luksusowy sedan emanujący elegancją. Jego doskonałe osiągi i wyjątkowy design sprawiają, że jest to wybór dla osób poszukujących luksusu i komfortu.', 1992, 'lig9_A0Cyt0', 3, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Mercedes-Benz', 'CL-Class', 'Elegancki coupe z mocnym sercem.', 'Mercedes-Benz CL-Class z 2010 roku to eleganckie coupe z potężnym silnikiem. Jego prestiżowy charakter i zaawansowane technologie sprawiają, że jest to wybór dla miłośników luksusu i doskonałej wydajności.', 2010, 'lig9_A0Cyt0', 5, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Dodge', 'Sprinter', 'Uniwersalny van z efektywnym przestrzenią.', 'Dodge Sprinter z 2009 roku to uniwersalny van z efektywną przestrzenią ładunkową. Jego praktyczne cechy i oszczędność sprawiają, że jest to niezawodny wybór dla biznesu i podróży.', 2009, 'lig9_A0Cyt0', 7, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Toyota', 'MR2', 'Sportowy roadster z duszą.', 'Toyota MR2 z 1992 roku to sportowy roadster z pasją do jazdy. Jego zwrotność i lekkość sprawiają, że dostarcza niezapomniane wrażenia za kierownicą dla miłośników motoryzacji.', 1992, 'lig9_A0Cyt0', 3, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Dodge', 'Intrepid', 'Dynamiczny sedan z charakterem.', 'Dodge Intrepid z 2004 roku to dynamiczny sedan o charakterystycznym designie. Jego agresywny charakter i wyjątkowy styl sprawiają, że jest to wybór dla osób ceniących sportowy wygląd.', 2004, 'lig9_A0Cyt0', 3, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Suzuki', 'SJ', 'Terminator wśród SUV-ów.', 'Suzuki SJ z 1995 roku to wszechstronny SUV z charakterystycznym designem. Jego zdolności terenowe i niezawodność sprawiają, że jest gotów na każdą przygodę na drodze i poza nią.', 1995, 'wPvBvRS6OQE', 5, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Honda', 'CR-V', 'Uniwersalny SUV z komfortem.', 'Honda CR-V z 2007 roku to uniwersalny SUV z doskonałym komfortem podróży. Jego przestronne wnętrze i efektywne osiągi sprawiają, że jest to idealny wybór dla rodzin i aktywnych podróżników.', 2007, 'feWMqBI8gms', 3, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Nissan', 'Sentra', 'Elegancki sedan z wyjątkowym stylem.', 'Nissan Sentra z 2010 roku to elegancki sedan z wyjątkowym stylem. Jego kompaktowe rozmiary i nowoczesne cechy sprawiają, że jest to doskonały wybór dla miłośników miejskiej elegancji.', 2010, 'feWMqBI8gms', 7, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Volkswagen', 'GTI', 'Kompaktowy hatchback z charakterem.', 'Volkswagen GTI z 1997 roku to kompaktowy hatchback z pasją do jazdy. Jego sportowe osiągi i stylowy design sprawiają, że jest to popularny wybór wśród miłośników dynamicznej motoryzacji.', 1997, 'wPvBvRS6OQE', 2, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Ford', 'Windstar', 'Przestronny van dla rodzin.', 'Ford Windstar z 2004 roku to przestronny van idealny dla rodzin. Jego komfortowe wnętrze i niezawodność sprawiają, że jest to praktyczny wybór dla codziennych podróży.', 2004, 'lig9_A0Cyt0', 3, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('BMW', 'M5', 'Wyrafinowany sedan z mocą M.', 'BMW M5 z 2001 roku to wyrafinowany sedan z mocą serii M. Jego doskonałe osiągi i sportowe cechy sprawiają, że jest to wybór dla miłośników luksusu i dynamicznej jazdy.', 2001, 'fYKQMRnOlR0', 3, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Lamborghini', 'Countach', 'Ikona supersamochodów z lat 80.', 'Lamborghini Countach z 1985 roku to ikona supersamochodów z lat 80. Jego agresywny design i potężne osiągi sprawiają, że jest to legendarne dzieło sztuki inżynierskiej.', 1985, 'wPvBvRS6OQE', 10, true);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Eagle', 'Talon', 'Muscle car z charakterem.', 'Eagle Talon z 1996 roku to muscle car z charakterem. Jego potężny silnik i agresywny design sprawiają, że dostarcza niezapomniane wrażenia z jazdy dla miłośników mocy.', 1996, 'gThLfTHR9q0', 3, false);

insert into car (brand, model, short_description, description, car_year, youtube_trailer_id, genre_id, promoted)
values ('Audi', '100', 'Klasyczny sedan z niemieckim stylem.', 'Audi 100 z 1989 roku to klasyczny sedan z niemieckim stylem. Jego elegancki wygląd i komfortowe wnętrze sprawiają, że jest to wybór dla osób ceniących klasę i doskonałą jakość.', 1989, 'fYKQMRnOlR0', 1, false);
