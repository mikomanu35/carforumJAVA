insert into
    car_rating (user_id, car_id, rating)
values
    (1, 1, 3),
    (1, 2, 4),
    (1, 3, 2),
    (2, 1, 5),
    (2, 2, 1),
    (2, 3, 5);